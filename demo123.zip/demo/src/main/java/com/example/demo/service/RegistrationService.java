package com.example.demo.service;
import com.example.demo.model.User;
public interface RegistrationService {

	 void registerUser(User user);
}
